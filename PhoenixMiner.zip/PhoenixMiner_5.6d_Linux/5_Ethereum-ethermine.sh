./PhoenixMiner -pool eu2.ethermine.org:4444 -wal 0x60f5B76AC2b269FAc0196dABC0dBAA54317d1fE4 -worker man1 -epsw x -mode 1 -log 0 -mport 0 -etha 0 -ftime 55 -retrydelay 1 -tt 79 -tstop 89  -coin eth
